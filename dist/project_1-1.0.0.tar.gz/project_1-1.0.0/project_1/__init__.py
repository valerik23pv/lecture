from .test_sql_injection import *
from .test_xss_web import *

__author__ = "vetkav"
__version__ = '1.0.0'
__email__ = 'soofy230@gmail.com'
